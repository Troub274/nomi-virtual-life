# Beth Peterson — uploader example

Use [BETH_UPLOADER.zip](BETH_UPLOADER.zip) or the checked-in `input/` files.
The bundle contains data and configuration, not an executable loader.
`source/` retains original diaries, canon and portrait; `input/` contains generated
Journal sections attributed to Beth Peterson, with reflection every five entries.
All 565 entries retain their numbering and dates. The existing converter omits the
editorial fictional-backstory disclaimer from upload text only; source diaries stay intact.

Create a new adult Nomi named **Beth Peterson**, age 38, dark hair, blue eyes,
height 5 feet 8 inches. Suggested traits: Thoughtful/Curious, Confident, Affectionate,
Romantic, Deep Conversations/Intellectual, Emotional and Imaginative. Leave backstory
blank. The portrait is a visual reference; do not upload it. For this controlled
experiment, wait until import completion before chatting. Canon is for evaluation afterward.

From the repository root, preview without credentials or API calls:

For the standard isolated package workflow, use `python examples/run_package.py beth --dry-run`,
`python examples/run_package.py beth` for live upload, and
`python examples/run_package.py beth --resume` to continue. State is kept under
`.local-runs/beth/`. The explicit commands below are an alternative with custom state paths.

```sh
python uploader/nomi-uploader.py --dry-run --nomi "Beth Peterson" --date-format US examples/beth/input/BETH01_V1.TXT examples/beth/input/BETH02_V1.TXT examples/beth/input/BETH03_V1.TXT examples/beth/input/BETH04_V1.TXT examples/beth/input/BETH05_V1.TXT
```

For live loading, set `NOMI_API_KEY` privately, remove `--dry-run --nomi "Beth Peterson"`,
and select Beth Peterson interactively. Use `--checkpoint beth_checkpoint.jsonl
--completion beth_completed.json --replies beth_replies.txt` to isolate this run.
Resume from the same working directory:

```sh
python uploader/nomi-uploader.py --resume --checkpoint beth_checkpoint.jsonl --completion beth_completed.json --replies beth_replies.txt
```

On Windows, `TEST_V1.BAT`, `START_V1.BAT`, and `RESUME_V1.BAT` prepare and use
`beth_v1/` with their own checkpoint paths. Do not switch paths midway through a run.
They require the repository's uploader two folders above them.
To regenerate inputs separately (never replace inputs of an active run):

```sh
python examples/beth/prepare_v1.py examples/beth/source --output new_beth_input --relive-every 5
```

Imports use rooms, not ordinary direct chat. Keep checkpoints and source files.
Transmission completion is not proof of long-term memory. See the
[uploader guide](../../uploader/README.md) and [recovery guide](../../uploader/RECOVERY.md).
